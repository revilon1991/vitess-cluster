export enum Intent {
    danger = 'danger',
    warning = 'warning',
    success = 'success',
    none = 'none',
}
