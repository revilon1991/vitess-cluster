import React from 'react';

const Divider: React.FC = () => <div className="border-gray-300 border-b" role="none"></div>;

export default Divider;
